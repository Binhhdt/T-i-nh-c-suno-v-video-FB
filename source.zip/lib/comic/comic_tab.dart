import 'dart:io';

import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:open_file/open_file.dart';
import 'package:path_provider/path_provider.dart';
import 'package:permission_handler/permission_handler.dart';
import 'package:webview_flutter/webview_flutter.dart';

import '../neon_theme.dart';
import '../save_folder.dart';
import '../save_folder_card.dart';
import '../suno_filename.dart';
import 'cbz_writer.dart';
import 'comic_downloader.dart';
import 'comic_log.dart';
import 'comic_models.dart';
import 'comic_scan_page.dart';

/// Tab "Truyện": tải ảnh trang của 1 chapter từ URL người dùng nhập, trên
/// trang mà người dùng có quyền tải. Quét bằng trình duyệt thật
/// (WebView), tải ảnh theo thứ tự 001, 002..., xuất thư mục ảnh / CBZ.
class ComicTab extends StatefulWidget {
  const ComicTab({super.key});

  @override
  State<ComicTab> createState() => _ComicTabState();
}

class _ComicTabState extends State<ComicTab>
    with AutomaticKeepAliveClientMixin {
  /// Giữ tab sống khi chuyển sang tab khác -> tải dở không bị huỷ.
  @override
  bool get wantKeepAlive => true;

  final _urlController = TextEditingController();
  final _log = ComicLog();
  final _downloader = ComicDownloader();

  bool _desktop = false;
  ExportMode _mode = ExportMode.folder;
  ScanResult? _scan;

  bool _downloading = false;
  bool _cancel = false;
  int _done = 0;
  int _total = 0;
  int _ok = 0;
  int _skipped = 0;
  int _failed = 0;

  String _status = '';
  bool _statusIsError = false;
  String? _outDir;
  String? _cbzPath;
  String? _firstFile;

  @override
  void initState() {
    super.initState();
    _log.onChanged = () {
      if (mounted) setState(() {});
    };
  }

  @override
  void dispose() {
    _log.onChanged = null;
    _urlController.dispose();
    super.dispose();
  }

  void _setStatus(String s, {bool error = false}) {
    if (!mounted) return;
    setState(() {
      _status = s;
      _statusIsError = error;
    });
  }

  String? _normalizeUrl(String raw) {
    var u = raw.trim();
    final found = RegExp(r'https?://\S+').firstMatch(u);
    if (found != null) u = found.group(0)!;
    if (u.isEmpty) return null;
    if (!u.startsWith('http://') && !u.startsWith('https://')) u = 'https://$u';
    final uri = Uri.tryParse(u);
    if (uri == null || uri.host.isEmpty) return null;
    return uri.toString();
  }

  Future<void> _startScan() async {
    FocusScope.of(context).unfocus();
    final url = _normalizeUrl(_urlController.text);
    if (url == null) {
      _setStatus('Link chapter không hợp lệ.', error: true);
      return;
    }
    setState(() {
      _scan = null;
      _outDir = null;
      _cbzPath = null;
      _firstFile = null;
      _done = _total = _ok = _skipped = _failed = 0;
    });
    _log.clear();
    _log.info('Quét: $url${_desktop ? ' (giao diện máy tính)' : ''}');
    _setStatus('Đang mở trang trong trình duyệt...');
    final result = await Navigator.of(context).push<ScanResult>(
      MaterialPageRoute(
        builder: (_) => ComicScanPage(url: url, desktop: _desktop),
      ),
    );
    if (!mounted) return;
    if (result == null) {
      _log.warn('Đã đóng trang quét, không có kết quả.');
      _setStatus('Chưa quét được trang nào.', error: true);
      return;
    }
    _log.addAll(result.log);
    setState(() => _scan = result);
    _setStatus('Tìm thấy ${result.images.length} trang — nguồn: '
        '${result.chosenSource}.');
  }

  /// Băm FNV-1a 32 bit -> 6 ký tự hex: phân biệt chapter cùng tiêu đề,
  /// và quét lại cùng link thì ra cùng thư mục (để bỏ qua file đã có).
  String _hash6(String s) {
    var h = 0x811c9dc5;
    for (final c in s.codeUnits) {
      h ^= c;
      h = (h * 0x01000193) & 0xFFFFFFFF;
    }
    return h.toRadixString(16).padLeft(8, '0').substring(0, 6);
  }

  Future<void> _ensurePermission() async {
    if (!Platform.isAndroid) return;
    try {
      final s = await Permission.storage.request();
      if (s.isGranted || s.isLimited) return;
      await Permission.photos.request();
    } catch (_) {}
  }

  /// Cookie của trình duyệt cho từng host ảnh (giống trình duyệt gửi khi
  /// tự tải ảnh). Không lưu ra đâu cả.
  Future<Map<String, String>> _cookiesFor(Iterable<String> hosts) async {
    final out = <String, String>{};
    for (final h in hosts) {
      try {
        final cookies = await WebViewCookieManager().getCookies(
          domain: Uri.parse('https://$h'),
        );
        final header = cookies
            .where((c) => c.name.isNotEmpty)
            .map((c) => '${c.name}=${c.value}')
            .join('; ');
        if (header.isNotEmpty) out[h] = header;
      } catch (_) {}
    }
    return out;
  }

  Future<void> _download() async {
    final scan = _scan;
    if (scan == null || scan.images.isEmpty || _downloading) return;
    await _ensurePermission();
    if (!mounted) return;
    setState(() {
      _downloading = true;
      _cancel = false;
      _done = 0;
      _total = scan.images.length;
      _ok = _skipped = _failed = 0;
      _outDir = null;
      _cbzPath = null;
      _firstFile = null;
    });
    _setStatus('Đang tải ${scan.images.length} trang...');

    try {
      final resolved = await resolveUserVisibleSaveDir();
      var title = sanitizeSongTitle(scan.title).replaceAll('.', ' ').trim();
      if (title.length > 60) title = title.substring(0, 60).trim();
      if (title.isEmpty) title = Uri.tryParse(scan.pageUrl)?.host ?? 'Chapter';
      final folderName = '$title (${_hash6(scan.pageUrl)})';

      // CBZ-only: ảnh để trong bộ nhớ đệm của app (vẫn bỏ qua file đã có
      // khi tải lại), chỉ file .cbz nằm ở thư mục lưu.
      final Directory imgDir;
      if (_mode == ExportMode.cbz) {
        final cache = await getTemporaryDirectory();
        imgDir = Directory('${cache.path}/comic/${_hash6(scan.pageUrl)}');
      } else {
        imgDir = Directory('${resolved.dir.path}/$folderName');
      }
      _log.info('Lưu ảnh vào: ${imgDir.path}');
      if (resolved.usedPrivateFallback) {
        _log.warn('Không ghi được vào thư mục đã chọn/Downloads -> dùng thư '
            'mục riêng của app.');
      } else if (resolved.usedFallback) {
        _log.warn('Thư mục đã chọn không dùng được -> dùng Downloads.');
      }

      final hosts = scan.images
          .map((e) => Uri.tryParse(e.url)?.host ?? '')
          .where((h) => h.isNotEmpty)
          .toSet();
      final cookies = await _cookiesFor(hosts);

      final report = await _downloader.downloadAll(
        images: scan.images,
        dir: imgDir,
        referer: scan.pageUrl,
        userAgent: scan.userAgent,
        log: _log,
        cookiesByHost: cookies,
        isCancelled: () => _cancel,
        onProgress: (done, total, last) {
          if (!mounted) return;
          setState(() {
            _done = done;
            if (last.state == PageState.done) _ok++;
            if (last.state == PageState.skipped) _skipped++;
            if (last.state == PageState.failed) _failed++;
          });
        },
      );
      if (!mounted) return;

      final files = report.filesInOrder;
      String? cbzPath;
      if (_mode != ExportMode.folder && files.isNotEmpty) {
        _setStatus('Đang đóng gói CBZ...');
        cbzPath = '${resolved.dir.path}/$folderName.cbz';
        if (report.failed > 0) {
          _log.warn('CBZ sẽ thiếu ${report.failed} trang bị lỗi.');
        }
        try {
          await CbzWriter.write(
            cbzPath,
            [for (final f in files) File(f)],
            title: scan.title,
            sourceUrl: scan.pageUrl,
          );
          _log.info('Đã tạo CBZ: $cbzPath (${files.length} trang)');
        } catch (e) {
          _log.error('Tạo CBZ thất bại: $e');
          cbzPath = null;
        }
      }

      // Ghi log cạnh kết quả.
      if (_mode == ExportMode.cbz) {
        await _log.saveTo('${resolved.dir.path}/$folderName.log.txt');
      } else {
        await _log.saveTo('${imgDir.path}/_log.txt');
      }

      final parts = <String>[
        'Tải mới ${report.ok}, bỏ qua (đã có) ${report.skipped}, '
            'lỗi ${report.failed} / ${scan.images.length} trang.',
      ];
      if (report.failed > 0) {
        parts.add('Xem "Nhật ký" bên dưới để biết lý do từng trang lỗi.');
      }
      if (_mode != ExportMode.folder) {
        parts.add(cbzPath != null ? 'Đã tạo CBZ.' : 'Không tạo được CBZ.');
      }
      setState(() {
        _outDir = _mode == ExportMode.cbz ? null : imgDir.path;
        _cbzPath = cbzPath;
        _firstFile = files.isNotEmpty ? files.first : null;
      });
      _setStatus(parts.join(' '), error: files.isEmpty);
    } catch (e) {
      _log.error('Lỗi khi tải: $e');
      _setStatus('Tải thất bại: $e', error: true);
    } finally {
      if (mounted) setState(() => _downloading = false);
    }
  }

  @override
  Widget build(BuildContext context) {
    super.build(context);
    final scan = _scan;
    return SingleChildScrollView(
      padding: const EdgeInsets.all(16),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.stretch,
        children: [
          const Card(
            child: Padding(
              padding: EdgeInsets.all(12),
              child: Text(
                'Chỉ dùng với trang bạn có quyền tải nội dung. App mở trang '
                'bằng trình duyệt như bạn tự xem — không vượt CAPTCHA, đăng '
                'nhập hay trả phí. Nếu trang cần xác nhận, bạn tự làm trong '
                'khung trình duyệt rồi bấm "Quét lại".',
                style: TextStyle(fontSize: 13, color: NeonColors.muted),
              ),
            ),
          ),
          const SizedBox(height: 12),
          SaveFolderCard(onChanged: (_) {}),
          const SizedBox(height: 12),
          TextField(
            controller: _urlController,
            keyboardType: TextInputType.url,
            textInputAction: TextInputAction.done,
            onSubmitted: (_) => _downloading ? null : _startScan(),
            decoration: InputDecoration(
              labelText: 'Dán link chapter',
              hintText: 'https://...',
              border: const OutlineInputBorder(),
              suffixIcon: IconButton(
                icon: const Icon(Icons.paste),
                tooltip: 'Dán từ bộ nhớ tạm',
                onPressed: () async {
                  final d = await Clipboard.getData(Clipboard.kTextPlain);
                  if (d?.text != null) _urlController.text = d!.text!;
                },
              ),
            ),
          ),
          SwitchListTile(
            contentPadding: EdgeInsets.zero,
            title: const Text('Mở bằng giao diện máy tính'),
            subtitle: const Text(
              'Bật nếu bản điện thoại của trang không hiện đủ ảnh',
              style: TextStyle(fontSize: 12),
            ),
            value: _desktop,
            onChanged: _downloading ? null : (v) => setState(() => _desktop = v),
          ),
          GradientButton(
            onPressed: _downloading ? null : _startScan,
            icon: Icons.travel_explore,
            label: 'Quét trang',
          ),
          if (scan != null) ...[
            const SizedBox(height: 16),
            Text(
              '${scan.images.length} trang — ${scan.title.isEmpty ? scan.pageUrl : scan.title}',
              style: const TextStyle(fontWeight: FontWeight.bold),
            ),
            const SizedBox(height: 8),
            _buildGrid(scan),
            const SizedBox(height: 12),
            const Text('Xuất ra:'),
            const SizedBox(height: 6),
            SegmentedButton<ExportMode>(
              segments: const [
                ButtonSegment(value: ExportMode.folder, label: Text('Thư mục ảnh')),
                ButtonSegment(value: ExportMode.cbz, label: Text('CBZ')),
                ButtonSegment(value: ExportMode.both, label: Text('Cả hai')),
              ],
              selected: {_mode},
              onSelectionChanged: _downloading
                  ? null
                  : (s) => setState(() => _mode = s.first),
            ),
            const SizedBox(height: 12),
            GradientButton(
              onPressed: _downloading ? null : _download,
              icon: Icons.download,
              label: 'Tải ${scan.images.length} trang',
            ),
          ],
          if (_downloading) ...[
            const SizedBox(height: 16),
            LinearProgressIndicator(value: _total > 0 ? _done / _total : null),
            const SizedBox(height: 6),
            Text(
              'Đã xử lý $_done/$_total — mới $_ok, đã có $_skipped, lỗi $_failed',
              textAlign: TextAlign.center,
            ),
            TextButton(
              onPressed: _cancel ? null : () => setState(() => _cancel = true),
              child: Text(_cancel ? 'Đang dừng...' : 'Dừng'),
            ),
          ],
          if (!_downloading && (_firstFile != null || _cbzPath != null)) ...[
            const SizedBox(height: 12),
            if (_firstFile != null && _mode != ExportMode.cbz)
              GradientButton(
                onPressed: () => OpenFile.open(_firstFile!),
                icon: Icons.image,
                label: 'Mở trang đầu',
              ),
            if (_cbzPath != null) ...[
              const SizedBox(height: 8),
              GradientButton(
                onPressed: () => OpenFile.open(_cbzPath!),
                icon: Icons.menu_book,
                label: 'Mở file CBZ',
              ),
            ],
            if (_outDir != null) ...[
              const SizedBox(height: 6),
              Text('Thư mục ảnh: $_outDir',
                  style: const TextStyle(fontSize: 12, color: NeonColors.muted)),
            ],
            if (_cbzPath != null) ...[
              const SizedBox(height: 4),
              Text('File CBZ: $_cbzPath',
                  style: const TextStyle(fontSize: 12, color: NeonColors.muted)),
            ],
          ],
          if (_status.isNotEmpty) ...[
            const SizedBox(height: 12),
            Text(
              _status,
              style: TextStyle(color: _statusIsError ? NeonColors.error : null),
            ),
          ],
          const SizedBox(height: 12),
          _buildLog(),
        ],
      ),
    );
  }

  Widget _buildGrid(ScanResult scan) {
    final headers = <String, String>{
      'Referer': scan.pageUrl,
      if (scan.userAgent.isNotEmpty) 'User-Agent': scan.userAgent,
    };
    return GridView.builder(
      shrinkWrap: true,
      physics: const NeverScrollableScrollPhysics(),
      itemCount: scan.images.length,
      gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(
        crossAxisCount: 4,
        mainAxisSpacing: 4,
        crossAxisSpacing: 4,
        childAspectRatio: 0.7,
      ),
      itemBuilder: (_, i) {
        final img = scan.images[i];
        return Stack(
          fit: StackFit.expand,
          children: [
            ClipRRect(
              borderRadius: BorderRadius.circular(4),
              child: Image.network(
                img.url,
                headers: headers,
                fit: BoxFit.cover,
                cacheWidth: 200,
                errorBuilder: (_, _, _) => Container(
                  color: Colors.black26,
                  child: const Icon(Icons.broken_image, size: 18),
                ),
              ),
            ),
            Positioned(
              left: 2,
              bottom: 2,
              child: Container(
                padding: const EdgeInsets.symmetric(horizontal: 4),
                color: Colors.black54,
                child: Text(img.baseName, style: const TextStyle(fontSize: 10)),
              ),
            ),
          ],
        );
      },
    );
  }

  Widget _buildLog() {
    final lines = _log.lines;
    final shown = lines.length > 300 ? lines.sublist(lines.length - 300) : lines;
    return Card(
      child: ExpansionTile(
        title: Text('Nhật ký (${lines.length} dòng)'),
        children: [
          Align(
            alignment: Alignment.centerRight,
            child: TextButton.icon(
              onPressed: lines.isEmpty
                  ? null
                  : () {
                      Clipboard.setData(ClipboardData(text: lines.join('\n')));
                      ScaffoldMessenger.of(context).showSnackBar(
                        const SnackBar(content: Text('Đã chép nhật ký')),
                      );
                    },
              icon: const Icon(Icons.copy, size: 16),
              label: const Text('Chép'),
            ),
          ),
          Container(
            constraints: const BoxConstraints(maxHeight: 320),
            padding: const EdgeInsets.fromLTRB(12, 0, 12, 12),
            child: SingleChildScrollView(
              child: SelectableText(
                shown.isEmpty ? '(trống)' : shown.join('\n'),
                style: const TextStyle(fontSize: 11, fontFamily: 'monospace'),
              ),
            ),
          ),
        ],
      ),
    );
  }
}
