allprojects {
    repositories {
        // Repo local (seeded by curl) FIRST: sandbox proxy breaks Java HTTP,
        // so Gradle must resolve artifacts without network. google() /
        // mavenCentral() remain as fallback.
        maven { url = uri("file:///home/hatch/local-maven") }
        google()
        mavenCentral()
    }
}

val newBuildDir: Directory =
    rootProject.layout.buildDirectory
        .dir("../../build")
        .get()
rootProject.layout.buildDirectory.value(newBuildDir)

subprojects {
    val newSubprojectBuildDir: Directory = newBuildDir.dir(project.name)
    project.layout.buildDirectory.value(newSubprojectBuildDir)
}
subprojects {
    project.evaluationDependsOn(":app")
}

tasks.register<Delete>("clean") {
    delete(rootProject.layout.buildDirectory)
}
